     <%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>

<center><h1>Information of Staff</h1></center>
<form action="/Lab4/add" method="post" enctype="multipart/form-data">
<div class="form-group">
<label>Tên đăng nhập</label>
<input type="fullname" name="text"/>
</div>
<div class="form-group">
<label>Mật khẩu</label>
<input type="password" name="password">
</div>

<div class="form-group">
<label>Ảnh đại diện</label>
<input type="file" name="photo_file">
</div>

<div class="form-group">
<label>Giới tính</label>
<input type="radio" name="gender" value="True"> Male
<input type="radio" name="gender" value="False"> Female
</div>

<div class="form-group">
<input type="checkbox" name="married"> Đã có gia đình?
</div>

<div class="form-group">
<label>Quốc gia</label>
<select name="country">
<option selected disabled>Country</option>
<option value="VN">Vietnam</option>
<option value="US">United States</option>
<option value="UK">United Kingdom</option>
</select>
</div>

<div class="form-group">
<label>Sở thích</label>
<input type="checkbox" name="hobbies" value="Coding"/> Coding
<input type="checkbox" name="hobbies" value="Travel"/> Travel
<input type="checkbox" name="hobbies" value="Music"/> Music
<input type="checkbox" name="hobbies" value="Other"/> Other
</div>

<div class="form-group">
<label>Ghi chú</label>
<textarea name="note"></textarea>
</div>

<button type="Submit">Đăng ký</button>
</form>

<a href="/Lab4">Trang chủ</a>
</body>
</html>