<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri = "http://java.sun.com/jsp/jstl/core" prefix = "c" %>
<%@ taglib uri = "http://java.sun.com/jsp/jstl/fmt" prefix = "fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="../menu.jsp"></jsp:include>
<hr/>
<c:url value = "calculate" var="cal"/>
<form method="post">
<input name="a"><br>
<input name="b"><br>
<button formaction="/Lab4/${cal}/add">+</button>
<button formaction="/Lab4/${cal}/sub">-</button>
</form>
${message}
</body>
</html>