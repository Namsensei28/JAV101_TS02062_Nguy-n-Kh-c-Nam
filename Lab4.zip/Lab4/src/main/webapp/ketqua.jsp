<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1>Kết quả đăng ký</h1>
	<p><strong>Tên đăng nhập:</strong> ${fullname}</p>
	<p><strong>Mật khẩu:</strong> ${password}</p>
	
	<p><strong>Giới tính:</strong> 
		<c:choose>
			<c:when test="${gender == 'True'}">Nam</c:when>
			<c:otherwise>Nữ</c:otherwise>
		</c:choose>
	</p>
	
	<p><strong>Đã có gia đình:</strong> ${married}</p>
	
	<p><strong>Quốc gia:</strong> ${country}</p>
	
	<p><strong>Sở thích:</strong> 
		<c:if test="${not empty hobbies}">
			<ul>
				<c:forEach var="hobby" items="${hobbies}">
					<li>${hobby}</li>
				</c:forEach>
			</ul>
		</c:if>
		<c:if test="${empty hobbies}">
			Không có sở thích được chọn
		</c:if>
	</p>
	
	<p><strong>Ghi chú:</strong> 
		<c:if test="${not empty note}">
			${note}
		</c:if>
		<c:if test="${empty note}">
			Không có ghi chú
		</c:if>
	</p>
	
	<p><strong>Ảnh đại diện:</strong></p>
	<img alt="Ảnh đại diện" src="${photoURL}" style="max-width: 200px;"/>
	
	<a href="/Lab4">Trở lại trang chủ</a>
</body>
</html>