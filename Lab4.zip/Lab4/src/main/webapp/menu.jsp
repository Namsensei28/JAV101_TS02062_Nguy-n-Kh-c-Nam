<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<a href="/Lab4/account/login">Bai1</a> ||
<a href="/Lab4/calculate">Bai2</a> ||
<a href="/Lab4/add">Bai3</a>
<hr>
</body>
</html>