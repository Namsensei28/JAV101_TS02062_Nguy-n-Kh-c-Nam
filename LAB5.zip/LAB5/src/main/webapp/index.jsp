<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Menu LAB5</title>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Inter', sans-serif;
        background: #f0f3f7;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .menu-container {
        background: #ffffff;
        margin-top: 60px;
        padding: 25px 40px;
        border-radius: 16px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        width: 420px;
        text-align: center;
    }

    h2 {
        margin-bottom: 20px;
        color: #333;
        font-weight: 600;
        letter-spacing: 1px;
    }

    .menu a {
        display: block;
        padding: 14px;
        margin: 10px 0;
        background: #4b8df8;
        color: white;
        text-decoration: none;
        border-radius: 12px;
        font-size: 17px;
        transition: 0.3s;
        font-weight: 500;
    }

    .menu a:hover {
        background: #1e5cd8;
        transform: translateY(-3px);
        box-shadow: 0 6px 15px rgba(0,0,0,0.15);
    }

    .home-link {
        margin-top: 10px;
        display: inline-block;
        padding: 10px 20px;
        background: #00c896;
        color: white;
        border-radius: 10px;
        text-decoration: none;
        font-weight: 500;
        transition: 0.3s;
    }

    .home-link:hover {
        background: #009f76;
        transform: translateY(-3px);
    }
</style>

</head>
<body>

<div class="menu-container">
    <h2>LAB 5 - MENU</h2>

    <div class="menu">
        <a href="login">Bài 1 – Login</a>
        <a href="add">Bài 2 – BeanUtil</a>
        <a href="upload">Bài 3 – Upload File</a>
        <a href="mail">Bài 4 – Gửi Email</a>
    </div>

    <a class="home-link" href="/LAB5">Trang chủ</a>
</div>

</body>
</html>
