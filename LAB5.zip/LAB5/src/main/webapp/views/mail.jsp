<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Send Mail</title>

<style>
    body {
        background: #E6E2C3;
        color: #1C315E;
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding-top: 40px;
    }

    h1 {
        text-align: center;
        margin-bottom: 10px;
        font-size: 34px;
    }

    mark {
        background: transparent;
        color: #C74B50;
        font-size: 18px;
        font-weight: bold;
    }

    form {
        width: 380px;
        background: #fff;
        padding: 25px 30px;
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        margin-top: 10px;
    }

    .group {
        margin-bottom: 18px;
    }

    .label {
        font-weight: 600;
        margin-bottom: 6px;
        display: block;
        color: #1C315E;
    }

    .input, textarea {
        width: 100%;
        padding: 12px 14px;
        border-radius: 8px;
        border: 1px solid #88A47C;
        background: #F7F6E7;
        font-size: 15px;
        transition: 0.25s ease;
        outline: none;
    }

    .input:focus,
    textarea:focus {
        border-color: #1C315E;
        background: #fff;
        box-shadow: 0 0 0 3px rgba(28,49,94,0.15);
    }

    textarea {
        height: 120px;
        resize: vertical;
    }

    .wrap {
        display: flex;
        justify-content: center;
        margin-top: 15px;
    }

    .button {
        width: 100%;
        padding: 12px;
        font-size: 18px;
        font-weight: 700;
        background: linear-gradient(90deg, rgba(129,230,217,1) 0%, rgba(79,209,197,1) 100%);
        border: none;
        border-radius: 50px;
        cursor: pointer;
        transition: 0.3s;
        color: #1C315E;
    }

    .button:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 20px rgba(79,209,197,.55);
    }

    .home-link {
        margin-top: 20px;
        display: block;
        text-align: center;
        font-weight: bold;
        color: #1C315E;
        text-decoration: none;
        transition: 0.25s;
    }

    .home-link:hover {
        text-decoration: underline;
    }
</style>
</head>

<body>

    <div>
        <h1>Send Mail</h1>
        <mark>${message}</mark>

        <form action="/LAB5/mail" method="post" enctype="multipart/form-data">

            <div class="group">
                <label class="label">From</label>
                <input name="from" type="text" class="input">
            </div>

            <div class="group">
                <label class="label">To</label>
                <input name="to" type="text" class="input">
            </div>

            <div class="group">
                <label class="label">Subject</label>
                <input name="subject" type="text" class="input">
            </div>

            <div class="group">
                <label class="label">Body</label>
                <textarea name="body"></textarea>
            </div>

            <div class="group">
                <label class="label">File đính kèm</label>
                <input type="file" name="photo_file" class="input">
            </div>

            <div class="wrap">
                <button type="submit" class="button">Send</button>
            </div>

        </form>

        <a href="/LAB5/mail" class="home-link">Trang chủ</a>
    </div>

</body>
</html>
