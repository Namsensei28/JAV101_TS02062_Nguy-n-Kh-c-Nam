<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Staff</title>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: linear-gradient(to right, #dfe9f3, #ffffff);
        display: flex;
        justify-content: center;
        padding-top: 30px;
        color: #333;
    }

    .card {
        width: 550px;
        border-radius: 18px;
        padding: 25px 30px;
        box-shadow: 0px 8px 20px rgba(0,0,0,0.15);
        background: #ffffff;
        border: none;
        animation: fade 0.5s ease;
    }

    @keyframes fade {
        from {opacity: 0; transform: translateY(20px);}
        to {opacity: 1; transform: translateY(0);}
    }

    h1 {
        text-align: center;
        margin-bottom: 25px;
        font-weight: 600;
        color: #3A4750;
    }

    .form-control, select, textarea {
        border-radius: 10px !important;
        border: 1px solid #ced4da !important;
        padding: 10px 14px !important;
        font-size: 15px !important;
    }

    .input-group-text {
        border-radius: 10px 0 0 10px !important;
        font-weight: 500;
        background: #3C8DBC;
        color: white;
    }

    .radio, .checkbox {
        margin-left: 8px;
        margin-right: 3px;
    }

    /* Modern Button */
    .btn-add {
        width: 100%;
        padding: 12px;
        border-radius: 50px;
        background: linear-gradient(90deg, #5DD39E, #348F50);
        color: white;
        font-size: 18px;
        font-weight: 600;
        border: none;
        transition: 0.3s;
    }

    .btn-add:hover {
        opacity: 0.85;
        transform: translateY(-3px);
        box-shadow: 0px 8px 15px rgba(0,0,0,0.2);
    }

    a.home {
        display: block;
        text-align: center;
        margin-top: 15px;
        font-size: 16px;
        color: #0077cc;
        text-decoration: none;
        font-weight: 500;
    }

    a.home:hover {
        text-decoration: underline;
    }
</style>

</head>
<body>

<div class="card">
    <h1>New Staff Profile</h1>

    <form action="/LAB5/add" method="post" enctype="multipart/form-data">

        <div class="input-group mb-3">
            <span class="input-group-text">Fullname</span>
            <input name="fullname" type="text" class="form-control">
        </div>

        <div class="input-group mb-3">
            <input type="file" name="photo_file" class="form-control">
            <span class="input-group-text">Image</span>
        </div>

        <div class="input-group mb-3">
            <span class="input-group-text">Birthday</span>
            <input name="birthday" type="date" class="form-control">
        </div>

        <!-- Gender & Married -->
        <label style="font-weight: 500;">Gender:</label><br>
        <input type="radio" class="radio" name="gender" value="True"> Male
        <input type="radio" class="radio" name="gender" value="False"> Female

        <br><br>

        <input type="checkbox" name="married"> Married?

        <br><br>

        <!-- Country -->
        <select name="country" class="form-control mb-3">
            <option selected>Country</option>
            <option value="Vietnamese">Vietnamese</option>
            <option value="United States">United States</option>
            <option value="United Kingdom">United Kingdom</option>
        </select>

        <!-- Hobbies -->
        <label style="font-weight: 500;">Hobbies:</label><br>
        <input type="checkbox" name="hobbies" value="Coding" class="radio"> Coding
        <input type="checkbox" name="hobbies" value="Travel" class="radio"> Travel
        <input type="checkbox" name="hobbies" value="Music" class="radio"> Music
        <input type="checkbox" name="hobbies" value="Other" class="radio"> Other

        <br><br>

        <!-- Notes -->
        <textarea name="note" class="form-control" rows="3" placeholder="Notes..."></textarea>

        <br>

        <button type="submit" class="btn-add">Add</button>
    </form>

    <a href="/LAB5" class="home">Quay về trang chủ</a>
</div>

</body>
</html>
