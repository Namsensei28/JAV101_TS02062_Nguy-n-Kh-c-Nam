<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>

<head>
<meta charset="UTF-8">
<title>Login – PolyLab</title>

<style>
    body {
        margin: 0;
        padding: 0;
        background: linear-gradient(135deg, #88A47C, #1C315E);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        font-family: Arial, sans-serif;
        color: #E6E2C3;
    }

    .container {
        width: 380px;
        background: rgba(0, 0, 0, 0.25);
        padding: 40px 35px;
        border-radius: 25px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        backdrop-filter: blur(8px);
        text-align: center;
    }

    h1 {
        margin-bottom: 25px;
        font-size: 32px;
        font-weight: bold;
        color: #E6E2C3;
    }

    .input-group {
        text-align: left;
        margin-bottom: 18px;
    }

    .label {
        font-size: 16px;
        margin-bottom: 6px;
        display: block;
        font-weight: bold;
        color: #E6E2C3;
    }

    .input {
        width: 100%;
        padding: 10px;
        border-radius: 8px;
        background: #E6E2C3;
        border: 2px solid #88A47C;
        font-size: 15px;
        color: #1C315E;
        outline: none;
    }

    .input:focus {
        border-color: #4FD1C5;
        box-shadow: 0 0 10px rgba(79,209,197,.7);
    }

    .row-remember {
        text-align: left;
        margin: 10px 0 18px;
    }

    .button {
        width: 100%;
        padding: 12px;
        font-size: 20px;
        font-weight: bold;
        border: none;
        border-radius: 30px;
        cursor: pointer;
        background: linear-gradient(90deg, rgba(129,230,217,1) 0%, rgba(79,209,197,1) 100%);
        color: #1C315E;
        transition: .3s;
        box-shadow: 0 10px 25px rgba(79,209,197,.3);
    }

    .button:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 30px rgba(79,209,197,.5);
    }

    .message {
        margin-bottom: 10px;
        font-size: 15px;
        color: #ffaaaa;
        height: 20px;
    }

    a {
        color: #E6E2C3;
        text-decoration: none;
        margin-top: 12px;
        display: inline-block;
        font-weight: bold;
    }
</style>
</head>

<body>

    <div class="container">
        <h1>Login</h1>

        <div class="message">${message}</div>

        <form action="/LAB5/login" method="post">

            <div class="input-group">
                <label class="label">Username</label>
                <input name="username" value="${username}" type="text" class="input">
            </div>

            <div class="input-group">
                <label class="label">Password</label>
                <input name="password" value="${password}" type="password" class="input">
            </div>

            <div class="row-remember">
                <input type="checkbox" name="remember"> Remember me
            </div>

            <button class="button" type="submit">Login</button>
        </form>

        <a href="/LAB5">← Trang chủ</a>
    </div>

</body>
</html>
