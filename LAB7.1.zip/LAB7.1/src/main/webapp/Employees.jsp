<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jstl/fmt_rt" prefix="fmt" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Employees Management</title>

<!-- BOOTSTRAP 5.3 -->
<link rel="stylesheet" 
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<style>
    body { background:#f7f7f7; font-family:Segoe UI, sans-serif; }
    .form-box, .table-box {
        background:white; padding:25px; border-radius:10px;
        box-shadow:0 0 15px rgba(0,0,0,0.1); margin-bottom:25px;
    }
    .btn-control button{ margin-right:8px; }
    table thead{ background:#0d6efd; color:white; }
</style>
</head>
<body class="p-4">

<c:url var="path" value="/employees"/>

<div class="container">

    <!-- SEARCH BAR -->
    <form action="${path}/search" method="get" class="mb-4 d-flex">
        <input type="text" name="keyword" class="form-control me-2"
               placeholder="Search by ID or Fullname...">
        <button class="btn btn-primary">Search</button>
    </form>

    <!-- FORM -->
    <div class="form-box">
        <h4 class="mb-3 text-primary fw-bold">Employee Information</h4>

        <form method="post" class="row g-3">

            <div class="col-md-6">
                <label class="form-label">Id</label>
                <input name="id" class="form-control" value="${item.id}">
            </div>

            <div class="col-md-6">
                <label class="form-label">Fullname</label>
                <input name="fullname" class="form-control" value="${item.fullname}">
            </div>

            <div class="col-md-6">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" value="${item.password}">
            </div>

            <div class="col-md-6">
                <label class="form-label">Photo</label>
                <input name="photo" class="form-control" value="${item.photo}">
            </div>

            <div class="col-md-6">
                <label class="form-label me-3 d-block">Gender</label>
                <input type="radio" name="gender" value="true"  ${item.gender?"checked":""}> Male
                <input type="radio" name="gender" value="false" ${!item.gender?"checked":""} class="ms-3"> Female
            </div>

            <div class="col-md-6">
                <label class="form-label">Birthday</label>
                <input type="date" name="birthday" class="form-control"
                       value="<fmt:formatDate value='${item.birthday}' pattern='yyyy-MM-dd'/>">
            </div>

            <div class="col-md-6">
                <label class="form-label">Salary</label>
                <input type="number" name="salary" class="form-control" value="${item.salary}">
            </div>

            <div class="col-md-6">
                <label class="form-label">Department ID</label>
                <input name="departmentId" class="form-control" value="${item.departmentId}">
            </div>

            <div class="col-12 btn-control mt-3">
                <button formaction="${path}/create" class="btn btn-success">Create</button>
                <button formaction="${path}/update" class="btn btn-primary">Update</button>
                <button formaction="${path}/delete" class="btn btn-danger">Delete</button>
                <button formaction="${path}/reset" class="btn btn-secondary">Reset</button>
            </div>
        </form>
    </div>

    <!-- TABLE -->
    <div class="table-box">
        <h4 class="mb-3 fw-bold text-primary">Employees List</h4>

        <table class="table table-bordered table-hover text-center align-middle">
            <thead>
            <tr>
                <th>No.</th> <th>Id</th> <th>Fullname</th><th>Password</th>
                <th>Photo</th><th>Gender</th><th>Birthday</th>
                <th>Salary</th><th>Department ID</th><th>Action</th>
            </tr>
            </thead>

            <tbody>
            <c:forEach var="e" items="${list}" varStatus="vs">
                <tr>
                    <td>${vs.count}</td>
                    <td>${e.id}</td>
                    <td>${e.fullname}</td>
                    <td>${e.password}</td>
                    <td>${e.photo}</td>
                    <td>${e.gender ? "Male" : "Female"}</td>
                    <td><fmt:formatDate value="${e.birthday}" pattern="dd/MM/yyyy"/></td>
                    <td>${e.salary}</td>
                    <td>${e.departmentId}</td>
                    <td><a class="btn btn-sm btn-outline-primary" href="${path}/edit/${e.id}">Edit</a></td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>

</div>

</body>
</html>
