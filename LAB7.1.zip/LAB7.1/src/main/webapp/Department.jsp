<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8" %>
<%@ taglib uri="http://java.sun.com/jstl/fmt_rt" prefix="fmt" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Department Management</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px auto;
            width: 75%;
            background: #f5f5f5;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #1e80ff;
            letter-spacing: 1px;
        }

        /* FORM */
        form input, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        form label {
            font-weight: bold;
        }

        .btn-box button {
            padding: 8px 18px;
            border: none;
            margin: 5px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            color: white;
        }

        .btn-create { background:#22bb33; }
        .btn-update { background:#007bff; }
        .btn-delete { background:#d63031; }
        .btn-reset  { background:#636e72; }

        .btn-box button:hover { opacity: 0.85; }


        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
            background: white;
            border-radius: 6px;
            overflow: hidden;
        }

        th {
            background:#1e90ff;
            color:white;
            padding:10px;
        }

        td {
            padding:10px;
            border-bottom:1px solid #ddd;
        }

        tr:hover { background:#eaf2ff; }

        a.edit-btn {
            padding:5px 10px;
            background:#0984e3;
            border-radius:4px;
            color:white;
            text-decoration:none;
            font-size:13px;
        }
        a.edit-btn:hover { opacity:0.85; }

        /* Search Box */
        #search {
            margin-bottom:20px;
            display:flex;
            gap:10px;
        }
        #search input{
            width:300px;
            height:30px;
            padding-left:10px;
            border-radius:4px;
            border:1px solid #aaa;
        }
        #search button{
            padding:8px 15px;
            background:#0984e3;
            border:none;
            border-radius:5px;
            color:white;
            cursor:pointer;
        }
        #search button:hover { opacity:.85; }

    </style>
</head>
<body>

<h2>DEPARTMENT MANAGEMENT</h2>

<c:url var="path" value="/department"/>

<!-- ================= SEARCH ================= -->
<form action="${path}/search" method="get" id="search">
    <input type="text" name="keyword" placeholder="Search by ID or Name..." >
    <button type="submit">Search</button>
</form>

<!-- ================= FORM ================= -->
<form method="post">
    <label>Id:</label>
    <input name="id" value="${item.id}"><br><br>

    <label>Name:</label>
    <input name="name" value="${item.name}"><br><br>

    <label>Description:</label>
    <textarea name="description" rows="3">${item.description}</textarea>
    <br><br>

    <div class="btn-box">
        <button formaction="${path}/create" class="btn-create">Create</button>
        <button formaction="${path}/update" class="btn-update">Update</button>
        <button formaction="${path}/delete" class="btn-delete">Delete</button>
        <button formaction="${path}/reset"  class="btn-reset">Reset</button>
    </div>
</form>

<hr>

<!-- ================= TABLE ================= -->
<table>
    <thead>
    <tr>
        <th>No.</th>
        <th>Id</th>
        <th>Name</th>
        <th>Description</th>
        <th width="80px">Action</th>
    </tr>
    </thead>
    <tbody>
    <c:forEach var="d" items="${list}" varStatus="vs">
        <tr>
            <td>${vs.count}</td>
            <td>${d.id}</td>
            <td>${d.name}</td>
            <td>${d.description}</td>
            <td>
                <a class="edit-btn" href="${path}/edit/${d.id}">Edit</a>
            </td>
        </tr>
    </c:forEach>
    </tbody>
</table>

</body>
</html>
