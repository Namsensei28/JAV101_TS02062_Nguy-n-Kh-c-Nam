<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Menu</title>

<!-- =================== CSS =================== -->
<style>
    body {
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #4f93ce, #2b5daa);
        font-family: Arial, sans-serif;
        color: #fff;
    }

    .menu-box {
        background: rgba(255,255,255,0.1);
        padding: 40px 60px;
        border-radius: 15px;
        text-align: center;
        backdrop-filter: blur(8px);
        box-shadow: 0px 5px 20px rgba(0,0,0,0.25);
    }

    .menu-box h2 {
        font-size: 28px;
        margin-bottom: 30px;
        font-weight: bold;
        letter-spacing: 1px;
    }

    .btn-big {
        display: block;
        width: 260px;
        padding: 18px;
        margin: 15px auto;
        font-size: 20px;
        font-weight: bold;
        color: white;
        background: #1e82ff;
        border-radius: 10px;
        text-decoration: none;
        transition: 0.25s;
    }

    .btn-big:hover {
        background: #005ae0;
        transform: scale(1.07);
    }
</style>
</head>

<body>

<div class="menu-box">
    <h2>Chọn chức năng quản lý</h2>

    <a href="Department.jsp" class="btn-big">📁 Quản lý Department</a>
    <a href="Employees.jsp" class="btn-big">👥 Quản lý Employees</a>
</div>

</body>
</html>
