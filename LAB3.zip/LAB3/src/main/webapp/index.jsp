<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<a href="Lab3Bai1">Bài 1</a>||
<a href="Lab3Bai2">Bài 2</a>||
<a href="Lab3Bai3">Bai 3</a>||
<a href="Lab3Bai4">Bài 4</a>||
<hr/>
</body>
</html>