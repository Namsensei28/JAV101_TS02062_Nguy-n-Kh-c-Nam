package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.item;

@WebServlet("/listbai4")
public class Lab3Bai4controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setAttribute("nam", 1000);
		ArrayList<String> danhsach = new ArrayList<String>();
		danhsach.add("Cải sơn");
		danhsach.add("Cải");
		danhsach.add("Sảng");
		danhsach.add("Nặng");

		req.setAttribute("ds", danhsach);
		ArrayList<item> items = new ArrayList<>();

		items.add(new item("Nokia 2020", "at.jpg", 500, 0.1, new Date()));


		items.add(new item("cs1", "cs1.jpg", 700, 0.15, new Date()));
		items.add(new item("cs2", "cs2.jpg", 900, 0.25, new Date()));
		items.add(new item("cs3", "cs3.jpg", 55, 0.3, new Date()));

		req.setAttribute("items", items);
		req.getRequestDispatcher("listproducts.jsp").forward(req, resp);

	}
}
