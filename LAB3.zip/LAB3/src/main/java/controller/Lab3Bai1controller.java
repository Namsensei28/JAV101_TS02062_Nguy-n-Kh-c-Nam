package controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.country;
@WebServlet("/Lab3Bai1") // Sửa thành chữ hoa/thường như bạn muốn
public class Lab3Bai1controller extends HttpServlet
{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	List<country> list= List.of(new country("VN", "Viet Nam"),new country("US", "USA"), new country("CN","CHINA"));
	req.setAttribute("countries", list);
	req.getRequestDispatcher("lab3bai1.jsp").forward(req, resp);
}
}
