package Controller;

import java.io.IOException;		
	
import jakarta.servlet.ServletException;		
import jakarta.servlet.annotation.WebServlet;		
import jakarta.servlet.http.HttpServlet;		
import jakarta.servlet.http.HttpServletRequest;		
import jakarta.servlet.http.HttpServletResponse;		
@WebServlet("/Bai1")		
public class Bai1Controller extends HttpServlet{		
	@Override	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {	
		// TODO Auto-generated method stub
		req.getRequestDispatcher("Bai1.jsp").forward(req, resp);
	}	
}		
