<%@ page pageEncoding="UTF-8" contentType="text/html; charset=UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<hr />
	<img src="img/Logo.jpg" weight="1000px" height="500px" />
	<h1>
		<a href="Bai1">bai 1</a> <a href="Bai2">bai 2</a> <a href="bai3">bai3</a>
	</h1>

	<hr />
</body>
</html>