package poly.com.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/bai3Formservlet","/form/ud","/form/create"})
public class FormServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		resp.setContentType("text/html;charset=UTF-8");
				req.setAttribute("message", "Welcome to FPT Polytechnic");
				Map<String, Object> map = new HashMap<>();
				map.put("fullname","Đặng Tài Phú");
				map.put("gender", true);
				map.put("country", "Việt Nam");
				req.setAttribute("user", map);
				req.getRequestDispatcher("/form.jsp").forward(req, resp);
				
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = req.getRequestURI();
		if(uri.contains("/form/ud")) {
			String  fullname =  req .getParameter( "fullname" );
			System.out.println(fullname);
			String  gender =  req .getParameter( "gender" );
			
			String  country =  req .getParameter( "country" );
			
			Map<String, Object> map = new HashMap<>();
			map.put("fullname",fullname);
			map.put("gender", gender);
			map.put("country", country);
			req.setAttribute("user", map);
			req.setAttribute("capnhat", "Cập nhật thành công");
			req.getRequestDispatcher("/form.jsp").forward(req, resp);
			
		}else if(uri.contains("/form/create")){
			String fullname = req.getParameter("fullname");
			String gender = req.getParameter("gender");
			String country = req.getParameter("country");
			
			Map<String, Object> map = new HashMap<>();
			map.put("fullname",fullname);
			map.put("gender", gender);
			map.put("country", country);
			req.setAttribute("user", map);
			req.getRequestDispatcher("/themmoi.jsp").forward(req, resp);
		}
		
		
		
	}
	
}
