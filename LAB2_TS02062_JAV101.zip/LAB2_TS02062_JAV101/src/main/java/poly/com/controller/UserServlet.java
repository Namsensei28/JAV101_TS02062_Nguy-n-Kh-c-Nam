package poly.com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai2Userservlet")
public class UserServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setAttribute("message", "Welcome to FPT Polytechnic");
		req.setAttribute("now", new Date());
		Map<String, Object> map = new HashMap<>();
		map.put("fullname", "Đặng Tài Phú");
		map.put("gender", "Female");
		map.put("country", "Việt Nam");
		
		req.setAttribute("user", map);
		req.getRequestDispatcher("/page.jsp").forward(req, resp);
	}
}
