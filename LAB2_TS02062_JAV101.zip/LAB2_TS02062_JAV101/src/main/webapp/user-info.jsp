<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<b>MY INFORMATION</b>
	<ul>
		<li>Fullname: ${user.fullname}</li>
		<li>Gender: ${user.gender}</li>
		<li>Country: ${user.country}</li>
	</ul>
</body>
</html>