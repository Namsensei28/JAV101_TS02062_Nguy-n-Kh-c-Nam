<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<a href="bai1shareservlet">Bai1 </a> ||
<a href="bai2Userservlet">Bai2 </a> ||
<a href="bai3Formservlet">Bai3 </a> ||
<a href="bai4">Bai4 </a> ||

</body>
</html>